package com.example.wallpaperapp;

import android.content.res.AssetManager;
import android.graphics.BitmapFactory;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.wallpaperapp.categories.CategoriesAdapter;
import com.example.wallpaperapp.categories.CategoriesList;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private final List<CategoriesList> categoriesList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final RecyclerView categoriesRecyclerView = findViewById(R.id.categoriesRecyclerView);
        categoriesRecyclerView.setHasFixedSize(true);
        categoriesRecyclerView.setLayoutManager(new GridLayoutManager(MainActivity.this, 2));

        AssetManager assetManager = getAssets()

        try {
            InputStream dbzIs = assetManager.open("dbz.jpg");
            Bitmap dbzCategoryImg = BitmapFactory.decodeStream(dbzIs);

            InputStream mhaIs = assetManager.open("deku.jpg");
            Bitmap mhaCategoryImg = BitmapFactory.decodeStream(mhaIs);

            InputStream narutoIs = assetManager.open("naruto.jpg");
            Bitmap narutoCategoryImg = BitmapFactory.decodeStream(narutoIs);

            CategoriesList dbzCategory = new CategoriesList("Dbz", dbzCategoryImg);
            categoriesLists.add(dbzCategory);

            CategoriesList mhaCategory = new CategoriesList("Mha", mhaCategoryImg);
            categoriesLists.add(mhaCategory);

            CategoriesList narutoCategory = new CategoriesList("Naruto", narutoCategoryImg);
            categoriesLists.add(narutoCategory);

            categoriesRecyclerView.setAdapter(new CategoriesAdapter(MainActivity.this, categoriesList));


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}