package com.example.wallpaperapp.wallpapers;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.res.AssetManager;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.wallpaperapp.R;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class Wallpapers extends AppCompatActivity {

    private final List<WallpapersList> wallpapersLists = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wallpapers);

        final ImageView backBtn = findViewById(R.id.backBtn);
        final TextView categoryName = findViewById(R.id.categoryName);
        final RecyclerView wallpaperRecyclerView = findViewById(R.id.wallpapersRecyclerView);

        final String getCategory = getIntent().getStringExtra("category");

        categoryName.setText(getCategory);

        wallpaperRecyclerView.setLayoutManager(new GridLayoutManager(Wallpapers.this, 2));
        wallpaperRecyclerView.setItemViewCacheSize(20);
        wallpaperRecyclerView.setDrawingCacheEnabled(true);

        AssetManager assetManager = getAssets();

        ProgressDialog progressDialog = new ProgressDialog(true);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Loading...");
        progressDialog.show();

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (getCategory.equals("Dbz")) {


                        InputStream dbzIs_1 = assetManager.open("dbz.jpg");
                        Bitmap dbzImage1 = BitmapFactory.decodeStream(dbzIs_1);

                        InputStream dbzIs_2 = assetManager.open("dbz2.jpg");
                        Bitmap dbzImage2 = BitmapFactory.decodeStream(dbzIs_2);


                        WallpapersList dbzList1 = new WallpapersList("dbz.jpg", dbzImage1);
                        wallpapersList.add(dbzList1);

                        WallpapersList dbzList2 = new WallpapersList("dbz2.jpg", dbzImage2);
                        wallpapersList.add(dbzList2);

                    } else if (getCategory.equals("naruto")) {

                        InputStream narutoIs_1 = assetManager.open("naruto.jpg");
                        Bitmap narutoImg1 = BitmapFactory.decodeStream(narutoIs_1);

                        InputStream narutoIs_2 = assetManager.open("naruto2.jpg");
                        Bitmap narutoImg2 = BitmapFactory.decodeStream(narutoIs_2);

                        WallpapersList narutoList1 = new WallpapersList("naruto.jpg", narutoImg1);
                        wallpapersLists.add(narutoList1);

                        WallpapersList narutoList2 = new WallpapersList("naruto2.jpg", narutoImg2);
                        wallpapersLists.add(narutoList2);


                    }

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            progressDialog.dismiss();

                            wallpaperRecyclerView.setAdapter(new WallpapersAdapter(Wallpapers.this, wallpapersLists));
                        }
                    });
                }
                catch (IOException e){
                    e.printStackTrace();

                )
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}